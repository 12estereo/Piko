package com.drone.defender;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.util.*;

public class MainActivity extends Activity {
    TextView status, count, log;
    RadarView radar;
    int detections = 0;
    boolean simulation = false;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    GradientDrawable bg(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(14));
        d.setStroke(dp(1), stroke); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(null, 1);
        return t;
    }
    LinearLayout card() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(1);
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        l.setBackground(bg(Color.rgb(10,25,19), Color.rgb(35,83,57)));
        return l;
    }
    void gap(LinearLayout root, int h) {
        View v = new View(this); root.addView(v, new LinearLayout.LayoutParams(1,dp(h)));
    }
    Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.rgb(5,18,10));
        b.setAllCaps(false); b.setTextSize(14);
        b.setBackground(bg(Color.rgb(124,255,107), Color.rgb(124,255,107)));
        return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,17,13));
        getWindow().setNavigationBarColor(Color.rgb(7,17,13));
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1);
        root.setPadding(dp(16),dp(16),dp(16),dp(22));
        root.setBackgroundColor(Color.rgb(5,13,10));
        scroll.addView(root); setContentView(scroll);

        TextView title = text("DRONE DEFENDER",24,Color.rgb(124,255,107),true);
        root.addView(title);
        root.addView(text("TACTICAL MONITOR  •  V1.0",11,Color.LTGRAY,true));
        gap(root,14);

        LinearLayout state = card();
        state.addView(text("SISTEMA DE VIGILANCIA",13,Color.rgb(124,255,107),true));
        status = text("●  MODO DEMOSTRACIÓN — SIN SENSORES",12,Color.WHITE,true);
        state.addView(status); root.addView(state); gap(root,12);

        LinearLayout radarCard = card();
        radarCard.addView(text("RADAR VISUAL",16,Color.WHITE,true));
        radar = new RadarView(this);
        radarCard.addView(radar,new LinearLayout.LayoutParams(-1,dp(255)));
        radarCard.addView(text("Radar gráfico de prueba. No detecta drones reales.",11,Color.LTGRAY,false));
        root.addView(radarCard); gap(root,12);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout c1=card(), c2=card();
        c1.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));
        c2.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));
        c1.addView(text("OBJETIVOS SIMULADOS",10,Color.LTGRAY,true));
        count=text("0",26,Color.rgb(124,255,107),true); c1.addView(count);
        c2.addView(text("ESTADO",10,Color.LTGRAY,true));
        c2.addView(text("SEGURO",21,Color.rgb(124,255,107),true));
        stats.addView(c1); View spacer=new View(this); stats.addView(spacer,new LinearLayout.LayoutParams(dp(10),1)); stats.addView(c2);
        root.addView(stats); gap(root,12);

        LinearLayout sim = card();
        sim.addView(text("SIMULADOR DE DEFENSA",16,Color.WHITE,true));
        sim.addView(text("Prueba alertas y seguimiento con contactos virtuales. No controla armas ni interfiere señales.",12,Color.LTGRAY,false));
        gap(sim,8);
        Button start=button("＋  Simular detección");
        start.setOnClickListener(v -> {
            detections++;
            count.setText(String.valueOf(detections));
            status.setText("●  ALERTA DE PRUEBA — CONTACTO VIRTUAL");
            log.setText("• Contacto virtual #" + detections + " registrado\n" + log.getText());
            radar.addTarget();
        });
        sim.addView(start);
        Button clear=button("Reiniciar simulación");
        clear.setOnClickListener(v -> { detections=0; count.setText("0"); status.setText("●  MODO DEMOSTRACIÓN — SIN SENSORES"); log.setText("Sin eventos."); radar.clearTargets(); });
        sim.addView(clear); root.addView(sim); gap(root,12);

        LinearLayout map=card();
        map.addView(text("ZONA / MAPA",16,Color.WHITE,true));
        map.addView(text("Módulo preparado para integrar un mapa y sensores externos compatibles en una siguiente versión.",12,Color.LTGRAY,false));
        root.addView(map); gap(root,12);

        LinearLayout events=card();
        events.addView(text("REGISTRO DE EVENTOS",16,Color.WHITE,true));
        log=text("Sin eventos.",12,Color.LTGRAY,false); events.addView(log);
        root.addView(events); gap(root,14);
        root.addView(text("Aviso: la app no detecta drones por sí sola. La detección real requiere hardware y fuentes de datos compatibles. Ante un dron sospechoso, mantén distancia y contacta a las autoridades; no intentes derribarlo.",11,Color.rgb(190,205,195),false));
    }

    class RadarView extends View {
        Paint p=new Paint(3); int targets=0; float sweep=0;
        RadarView(Activity a){super(a);}
        void addTarget(){targets++; invalidate();}
        void clearTargets(){targets=0; invalidate();}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(), h=getHeight(), cx=w/2, cy=h/2, r=Math.min(w,h)*.43f;
            c.drawColor(Color.rgb(7,19,13));
            p.setColor(Color.rgb(25,90,52)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1));
            for(int i=1;i<=4;i++) c.drawCircle(cx,cy,r*i/4,p);
            c.drawLine(cx-r,cy,cx+r,cy,p); c.drawLine(cx,cy-r,cx,cy+r,p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(124,255,107));
            c.drawCircle(cx,cy,dp(3),p);
            for(int i=0;i<targets;i++){
                double a=i*2.4+0.8; float x=cx+(float)Math.cos(a)*r*(.35f+.1f*(i%4));
                float y=cy+(float)Math.sin(a)*r*(.35f+.1f*(i%4));
                p.setColor(Color.rgb(255,170,55)); c.drawCircle(x,y,dp(5),p);
            }
            p.setTextSize(dp(10)); p.setColor(Color.rgb(124,190,140));
            c.drawText("N",cx-4,cy-r-6,p); c.drawText("E",cx+r+5,cy+4,p);
        }
    }
}
