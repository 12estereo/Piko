# DRONE DEFENDER — Android V1
Interfaz táctica de vigilancia y simulación educativa.

## Incluye
- Panel táctico verde/negro.
- Radar gráfico con contactos virtuales.
- Simulador de detecciones y registro de eventos.
- Espacio reservado para integrar mapa y sensores externos.

## Limitaciones importantes
Esta versión es una demostración: el radar dibujado no detecta drones reales. La detección real requiere hardware o fuentes de datos compatibles. No incluye control de armas, explosivos, interferencia de radio ni funciones para derribar drones.

## Abrir y compilar
1. Descomprime el ZIP.
2. Abre la carpeta `DRONE_DEFENDER_V1` desde Android Studio.
3. Espera la sincronización de Gradle y acepta instalar los componentes SDK que solicite.
4. Selecciona `app` y pulsa Run para probar en un teléfono Android conectado.
5. Para generar APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

Requisitos orientativos: Android Studio reciente, JDK 17 y Android SDK 35.
