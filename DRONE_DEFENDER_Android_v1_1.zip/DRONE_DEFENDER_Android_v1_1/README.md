# DRONE DEFENDER 1.1

Aplicación Android de observación y registro de señales Bluetooth cercanas.

## Importante
- El radar visualiza el barrido y los dispositivos Bluetooth que el teléfono realmente recibe.
- Un punto en el radar NO confirma que sea un dron ni indica una posición o distancia precisa.
- La detección fiable de drones requiere sensores y protocolos compatibles.
- La conexión HTTPS es opcional y necesita una dirección de servidor que entregue JSON con un arreglo `events`.
- No transmite interferencias, no toma control de aeronaves y no las neutraliza.

## Compilación
Abrir este proyecto en Android Studio o ejecutar `gradle assembleDebug` con Android SDK 35 y Java 17.
