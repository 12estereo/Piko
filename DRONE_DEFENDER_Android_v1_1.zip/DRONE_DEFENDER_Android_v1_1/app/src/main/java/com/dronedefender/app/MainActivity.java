package com.dronedefender.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 41;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, DeviceDot> devices = new LinkedHashMap<>();
    private TextView statusText, deviceText, eventText, httpStatus;
    private EditText endpointInput;
    private RadarView radar;
    private BluetoothLeScanner scanner;
    private boolean scanning = false;

    private static class DeviceDot {
        String address;
        String name;
        int rssi;
        DeviceDot(String a, String n, int r) { address=a; name=n; rssi=r; }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 15, 17));
        getWindow().setNavigationBarColor(Color.rgb(5, 15, 17));
        buildScreen();
        updateDeviceList();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private void buildScreen() {
        int bg = Color.rgb(5, 15, 17), green = Color.rgb(75, 255, 160), muted = Color.rgb(160, 190, 180);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28));
        scroll.addView(root);

        TextView title = label("DRONE DEFENDER", 26, green);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title);
        TextView subtitle = label("CENTRO DE OBSERVACIÓN Y ALERTAS  •  V1.1", 11, muted);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        statusText = label("SISTEMA LISTO  •  ESPERANDO ESCANEO", 13, green);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(0, dp(18), 0, dp(10));
        root.addView(statusText);

        radar = new RadarView(this);
        LinearLayout.LayoutParams radarParams = new LinearLayout.LayoutParams(-1, dp(300));
        radarParams.topMargin = dp(8);
        radarParams.bottomMargin = dp(12);
        root.addView(radar, radarParams);

        TextView radarNote = label("RADAR VISUAL: muestra dispositivos Bluetooth recibidos; no confirma que sean drones ni calcula su ubicación real.", 12, muted);
        radarNote.setGravity(Gravity.CENTER);
        root.addView(radarNote);

        Button scanButton = button("INICIAR ESCANEO BLUETOOTH");
        root.addView(scanButton);
        scanButton.setOnClickListener(v -> startBleScan());

        Button stopButton = button("DETENER ESCANEO");
        root.addView(stopButton);
        stopButton.setOnClickListener(v -> stopBleScan());

        deviceText = label("DISPOSITIVOS: 0\\nTodavía no hay resultados.", 13, green);
        deviceText.setPadding(dp(10), dp(12), dp(10), dp(12));
        root.addView(deviceText);

        TextView divider1 = label("────────────────────────────────", 13, muted);
        divider1.setGravity(Gravity.CENTER);
        root.addView(divider1);

        TextView httpTitle = label("CONEXIÓN HTTPS OPCIONAL", 16, green);
        httpTitle.setTypeface(null, 1);
        root.addView(httpTitle);
        TextView httpHelp = label("Introduce la dirección HTTPS de tu servidor autorizado. No pegues enlaces al azar. El servidor debe responder JSON con un arreglo llamado events.", 12, muted);
        root.addView(httpHelp);
        endpointInput = new EditText(this);
        endpointInput.setSingleLine(true);
        endpointInput.setTextColor(Color.WHITE);
        endpointInput.setHintTextColor(Color.GRAY);
        endpointInput.setHint("https://tu-servidor.com/events");
        endpointInput.setTextSize(13);
        root.addView(endpointInput);
        Button connectButton = button("CONSULTAR SERVIDOR");
        root.addView(connectButton);
        connectButton.setOnClickListener(v -> fetchHttps());
        httpStatus = label("HTTPS: sin configurar", 12, muted);
        root.addView(httpStatus);

        TextView historyTitle = label("REGISTRO LOCAL", 16, green);
        historyTitle.setTypeface(null, 1);
        historyTitle.setPadding(0, dp(16), 0, dp(5));
        root.addView(historyTitle);
        eventText = label("Aplicación iniciada. No hay alertas.", 12, muted);
        root.addView(eventText);

        TextView footer = label("OBSERVAR • REGISTRAR • INFORMAR\\nSin interferencia ni control de aeronaves.", 11, muted);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(24), 0, 0);
        root.addView(footer);

        setContentView(scroll);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setTextColor(Color.rgb(5, 25, 18));
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(75, 255, 160)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(48));
        p.topMargin = dp(7); p.bottomMargin = dp(4);
        b.setLayoutParams(p);
        return b;
    }

    private boolean hasBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_PERMISSIONS);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSIONS);
        }
    }

    private void startBleScan() {
        if (!hasBlePermissions()) { requestBlePermissions(); return; }
        try {
            BluetoothManager manager = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
            if (adapter == null || !adapter.isEnabled()) {
                statusText.setText("BLUETOOTH APAGADO • ACTÍVALO EN AJUSTES");
                return;
            }
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { statusText.setText("ESCÁNER BLE NO DISPONIBLE"); return; }
            devices.clear();
            radar.setDevices(new ArrayList<>(devices.values()));
            scanner.startScan(scanCallback);
            scanning = true;
            statusText.setText("ESCANEANDO BLUETOOTH CERCANO…");
            addLog("Escaneo Bluetooth iniciado.");
            handler.postDelayed(() -> {
                if (scanning) {
                    stopBleScan();
                    statusText.setText("ESCANEO FINALIZADO • " + devices.size() + " DISPOSITIVOS");
                }
            }, 12000);
        } catch (SecurityException e) {
            statusText.setText("PERMISO BLUETOOTH NO CONCEDIDO");
        } catch (Exception e) {
            statusText.setText("NO SE PUDO INICIAR EL ESCANEO");
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null) return;
            try {
                String address = result.getDevice().getAddress();
                String name = result.getScanRecord() == null ? null : result.getScanRecord().getDeviceName();
                if (name == null || name.trim().isEmpty()) name = "Dispositivo sin nombre";
                devices.put(address, new DeviceDot(address, name, result.getRssi()));
                runOnUiThread(() -> {
                    radar.setDevices(new ArrayList<>(devices.values()));
                    updateDeviceList();
                });
            } catch (SecurityException ignored) { }
        }
        @Override public void onScanFailed(int errorCode) {
            runOnUiThread(() -> statusText.setText("FALLO DE ESCANEO BLE • CÓDIGO " + errorCode));
        }
    };

    private void stopBleScan() {
        try {
            if (scanner != null && scanning && hasBlePermissions()) scanner.stopScan(scanCallback);
        } catch (Exception ignored) { }
        scanning = false;
        if (statusText != null && statusText.getText().toString().startsWith("ESCANEANDO")) {
            statusText.setText("ESCANEO DETENIDO • " + devices.size() + " DISPOSITIVOS");
        }
    }

    private void updateDeviceList() {
        if (deviceText == null) return;
        StringBuilder s = new StringBuilder("DISPOSITIVOS RECIBIDOS: ").append(devices.size());
        if (devices.isEmpty()) s.append("\\nNo se han recibido señales Bluetooth todavía.");
        int count = 0;
        for (DeviceDot d : devices.values()) {
            if (count++ >= 8) { s.append("\\n… y más"); break; }
            s.append("\\n• ").append(d.name).append("  |  RSSI ").append(d.rssi).append(" dBm");
        }
        deviceText.setText(s.toString());
    }

    private void addLog(String message) {
        if (eventText != null) eventText.setText(message + "\\n" + eventText.getText());
    }

    private void fetchHttps() {
        String endpoint = endpointInput.getText().toString().trim();
        if (!endpoint.startsWith("https://")) {
            httpStatus.setText("HTTPS: escribe una dirección segura que comience por https://");
            return;
        }
        httpStatus.setText("HTTPS: consultando…");
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection)new URL(endpoint).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(8000);
                connection.setRequestProperty("Accept", "application/json");
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                java.io.InputStream in = connection.getInputStream();
                java.util.Scanner scanner = new java.util.Scanner(in, "UTF-8").useDelimiter("\\A");
                String body = scanner.hasNext() ? scanner.next() : "";
                JSONObject json = new JSONObject(body);
                JSONArray events = json.optJSONArray("events");
                int total = events == null ? 0 : events.length();
                runOnUiThread(() -> {
                    httpStatus.setText("HTTPS: conectado • " + total + " eventos recibidos");
                    addLog("Consulta HTTPS correcta: " + total + " eventos.");
                });
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "error de conexión" : e.getMessage();
                runOnUiThread(() -> httpStatus.setText("HTTPS: no conectado • " + msg));
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            if (granted) startBleScan();
            else statusText.setText("PERMISOS NO CONCEDIDOS • ESCANEO DESACTIVADO");
        }
    }

    @Override protected void onPause() {
        super.onPause();
        stopBleScan();
    }

    private class RadarView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Handler h = new Handler(Looper.getMainLooper());
        private float angle = 0;
        private ArrayList<DeviceDot> points = new ArrayList<>();
        private final Runnable tick = new Runnable() {
            @Override public void run() {
                angle = (angle + 2.2f) % 360f;
                invalidate();
                h.postDelayed(this, 40);
            }
        };
        RadarView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); h.post(tick); }
        void setDevices(ArrayList<DeviceDot> list) { points = list; invalidate(); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth()/2f, cy = getHeight()/2f;
            float radius = Math.min(getWidth(), getHeight()) * 0.43f;
            canvas.drawColor(Color.rgb(5, 15, 17));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(Color.rgb(28, 115, 76));
            for (int i=1;i<=4;i++) canvas.drawCircle(cx, cy, radius*i/4f, p);
            canvas.drawLine(cx-radius,cy,cx+radius,cy,p);
            canvas.drawLine(cx,cy-radius,cx,cy+radius,p);
            p.setColor(Color.rgb(45, 110, 80));
            canvas.drawLine(cx-radius*0.7f,cy-radius*0.7f,cx+radius*0.7f,cy+radius*0.7f,p);
            canvas.drawLine(cx-radius*0.7f,cy+radius*0.7f,cx+radius*0.7f,cy-radius*0.7f,p);

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(35, 70, 255, 150));
            RectF sector = new RectF(cx-radius, cy-radius, cx+radius, cy+radius);
            canvas.drawArc(sector, angle-35, 35, true, p);
            p.setColor(Color.rgb(80, 255, 155)); p.setStrokeWidth(dp(2)); p.setStyle(Paint.Style.STROKE);
            double a = Math.toRadians(angle);
            canvas.drawLine(cx, cy, cx+(float)Math.cos(a)*radius, cy+(float)Math.sin(a)*radius, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE); p.setTextSize(dp(10));
            canvas.drawText("N", cx-4, cy-radius- dp(7), p);
            canvas.drawText("S", cx-4, cy+radius+ dp(15), p);
            canvas.drawText("W", cx-radius-dp(15), cy+4, p);
            canvas.drawText("E", cx+radius+dp(5), cy+4, p);

            int i=0;
            for (DeviceDot d : points) {
                // RSSI is only a rough signal-strength visualization, not distance or direction.
                float r = radius * (0.25f + (Math.abs(d.rssi) % 70) / 100f);
                float theta = (float)(i * 2.39996);
                float x = cx + (float)Math.cos(theta)*r;
                float y = cy + (float)Math.sin(theta)*r;
                p.setColor(Color.rgb(255, 190, 70));
                canvas.drawCircle(x,y,dp(4),p);
                i++;
            }
            p.setColor(Color.rgb(120, 190, 155)); p.setTextSize(dp(9));
            canvas.drawText(points.size()+" SEÑALES BLE", dp(8), getHeight()-dp(8), p);
        }
    }
}
