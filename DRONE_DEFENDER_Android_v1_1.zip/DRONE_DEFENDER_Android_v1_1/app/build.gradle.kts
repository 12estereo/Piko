plugins {
    id("com.android.application")
}

android {
    namespace = "com.dronedefender.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dronedefender.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
