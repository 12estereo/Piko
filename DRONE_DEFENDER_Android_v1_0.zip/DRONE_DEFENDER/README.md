# DRONE DEFENDER — Android V1.0

Complete Android Studio/Gradle source project.

## Included
- Android application source and manifest
- Gradle project configuration
- BLE scan interface for nearby Bluetooth Low Energy advertisers
- Manual sighting/event log stored locally
- Optional HTTPS JSON feed import from an endpoint the operator is authorized to access

## Detection limits
BLE scanning lists nearby BLE advertisers; it does not identify a device as a drone or detect all drones. Reliable physical detection requires a compatible dedicated sensor and a documented data interface. The HTTPS importer expects an authorized endpoint returning JSON with an `events` array.

Example:
```json
{
  "events": [
    {
      "name": "Sensor event",
      "timestamp": "2026-11-25T15:00:00Z",
      "source": "authorized-sensor",
      "description": "Detection reported by the external sensor"
    }
  ]
}
```

The app does not jam, spoof, take control of, or disable aircraft.

## Build
The separate GitHub Actions YAML supplied with this ZIP extracts this project and builds the debug APK.
