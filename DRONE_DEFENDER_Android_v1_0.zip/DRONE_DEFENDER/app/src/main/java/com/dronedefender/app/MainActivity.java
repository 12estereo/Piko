package com.dronedefender.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_BLE = 41;
    private static final long SCAN_WINDOW_MS = 15000L;

    private TextView statusView, eventView, bleView;
    private EditText feedUrl, manualNote;
    private BluetoothLeScanner scanner;
    private boolean scanning = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private final Map<String, Long> lastSeen = new HashMap<>();
    private final StringBuilder events = new StringBuilder();
    private android.content.SharedPreferences prefs;

    private String now() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private TextView makeText(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(dp(10), dp(9), dp(10), dp(9));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private Button makeButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(30, 105, 92)));
        return b;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("drone_defender", MODE_PRIVATE);
        events.append(prefs.getString("events", ""));
        buildUi();
        refreshEvents();
        initBluetooth();
        setStatus("LISTO · Modo local activo. La detección BLE muestra dispositivos cercanos, no confirma que sean drones.");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(18));
        root.setBackgroundColor(Color.rgb(12, 22, 29));

        TextView title = makeText("DRONE DEFENDER", 27, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        TextView subtitle = makeText("TACTICAL AWARENESS  •  V1.0", 12, Color.rgb(115, 205, 177), true);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(title);
        root.addView(subtitle);

        statusView = makeText("INICIALIZANDO…", 14, Color.WHITE, true);
        statusView.setBackgroundColor(Color.rgb(30, 48, 57));
        root.addView(statusView);

        root.addView(section("SENSORES LOCALES"));
        bleView = makeText("Bluetooth LE: preparando…", 13, Color.LTGRAY, false);
        root.addView(bleView);
        Button scan = makeButton("ESCANEAR BLUETOOTH (15 SEGUNDOS)");
        scan.setOnClickListener(v -> startBleScan());
        root.addView(scan);

        root.addView(section("REGISTRO MANUAL"));
        manualNote = new EditText(this);
        manualNote.setHint("Descripción, ubicación aproximada o referencia");
        manualNote.setTextColor(Color.WHITE);
        manualNote.setHintTextColor(Color.GRAY);
        manualNote.setMinLines(2);
        manualNote.setGravity(Gravity.TOP);
        root.addView(manualNote);
        Button add = makeButton("GUARDAR AVISTAMIENTO");
        add.setOnClickListener(v -> {
            String note = manualNote.getText().toString().trim();
            if (note.isEmpty()) note = "Avistamiento registrado sin descripción.";
            addEvent("MANUAL", note);
            manualNote.setText("");
        });
        root.addView(add);

        root.addView(section("FUENTE EXTERNA AUTORIZADA · HTTPS"));
        feedUrl = new EditText(this);
        feedUrl.setSingleLine(true);
        feedUrl.setTextColor(Color.WHITE);
        feedUrl.setHintTextColor(Color.GRAY);
        feedUrl.setHint("https://servidor-autorizado.example/api/events");
        feedUrl.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        root.addView(feedUrl);
        TextView contract = makeText(
            "Formato esperado: JSON con un arreglo 'events'. Cada elemento puede incluir 'name', 'timestamp', 'source' y 'description'. Usa únicamente endpoints HTTPS que tengas autorización para consultar.",
            12, Color.LTGRAY, false);
        root.addView(contract);
        Button fetch = makeButton("CONSULTAR FUENTE HTTPS");
        fetch.setOnClickListener(v -> fetchAuthorizedFeed());
        root.addView(fetch);

        root.addView(section("HISTORIAL DE EVENTOS"));
        eventView = makeText("Sin eventos.", 12, Color.rgb(220, 230, 232), false);
        eventView.setBackgroundColor(Color.rgb(24, 38, 46));
        root.addView(eventView);

        Button clear = makeButton("BORRAR HISTORIAL LOCAL");
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Borrar historial")
            .setMessage("¿Quieres borrar los eventos guardados en este teléfono?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Borrar", (d, w) -> {
                events.setLength(0);
                prefs.edit().remove("events").apply();
                refreshEvents();
            }).show());
        root.addView(clear);

        Button info = makeButton("LÍMITES Y SEGURIDAD");
        info.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Información importante")
            .setMessage("El escaneo BLE detecta anuncios Bluetooth cercanos; no identifica por sí solo drones. La detección física fiable requiere un sensor especializado compatible y una fuente de datos documentada. Esta aplicación no interfiere comunicaciones, no toma control de aeronaves y no intenta derribarlas.")
            .setPositiveButton("Entendido", null).show());
        root.addView(info);

        TextView footer = makeText("LOCAL FIRST  •  HTTPS OPTIONAL  •  NO JAMMING", 10, Color.rgb(115, 155, 165), true);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);

        scroll.addView(root);
        setContentView(scroll);
    }

    private TextView section(String name) {
        TextView t = makeText(name, 14, Color.rgb(104, 207, 177), true);
        t.setPadding(dp(4), dp(18), dp(4), dp(4));
        return t;
    }

    private void setStatus(String value) {
        statusView.setText(value);
    }

    private void initBluetooth() {
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) {
            bleView.setText("Bluetooth no disponible en este dispositivo.");
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        bleView.setText(scanner == null ? "Bluetooth LE no disponible o Bluetooth apagado." :
            "Bluetooth LE disponible. Escaneo pasivo bajo demanda.");
    }

    private boolean hasBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startBleScan() {
        if (scanner == null) {
            initBluetooth();
            if (scanner == null) {
                setStatus("Bluetooth LE no está disponible. Comprueba que esté activado.");
                return;
            }
        }
        if (!hasBlePermissions()) {
            if (Build.VERSION.SDK_INT >= 31) {
                requestPermissions(new String[] {
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                }, REQUEST_BLE);
            } else {
                requestPermissions(new String[] { Manifest.permission.ACCESS_FINE_LOCATION }, REQUEST_BLE);
            }
            return;
        }
        try {
            if (scanning) scanner.stopScan(scanCallback);
            lastSeen.clear();
            scanner.startScan(scanCallback);
            scanning = true;
            setStatus("ESCANEANDO BLE · 15 segundos. Los resultados no prueban que un dispositivo sea un dron.");
            handler.postDelayed(() -> {
                if (scanning) {
                    try { scanner.stopScan(scanCallback); } catch (SecurityException ignored) {}
                    scanning = false;
                    setStatus("Escaneo BLE terminado. Revisa los dispositivos observados.");
                }
            }, SCAN_WINDOW_MS);
        } catch (SecurityException e) {
            setStatus("Permiso Bluetooth no concedido. Autoriza el permiso y vuelve a intentar.");
        } catch (Exception e) {
            setStatus("No fue posible iniciar el escaneo: " + e.getMessage());
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            String address = result.getDevice() == null ? "dispositivo" : result.getDevice().getAddress();
            long current = System.currentTimeMillis();
            Long previous = lastSeen.get(address);
            if (previous != null && current - previous < 10000) return;
            lastSeen.put(address, current);
            String name = "BLE cercano";
            try {
                String deviceName = result.getDevice().getName();
                if (deviceName != null && !deviceName.trim().isEmpty()) name = deviceName;
            } catch (SecurityException ignored) {}
            String detail = name + " · RSSI " + result.getRssi() + " dBm · " + address;
            runOnUiThread(() -> {
                bleView.setText("Último dispositivo observado:\n" + detail +
                    "\n\nNota: BLE no identifica automáticamente drones.");
                addEvent("BLE", detail);
            });
        }

        @Override
        public void onScanFailed(int errorCode) {
            runOnUiThread(() -> setStatus("Escaneo BLE fallido. Código: " + errorCode));
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_BLE && hasBlePermissions()) startBleScan();
        else if (requestCode == REQUEST_BLE) setStatus("Permisos no concedidos. El registro manual sigue disponible.");
    }

    private void addEvent(String source, String description) {
        String line = "[" + now() + "] [" + source + "] " + description;
        events.insert(0, line + "\n");
        if (events.length() > 30000) events.setLength(30000);
        prefs.edit().putString("events", events.toString()).apply();
        refreshEvents();
    }

    private void refreshEvents() {
        if (eventView != null) eventView.setText(events.length() == 0 ? "Sin eventos." : events.toString());
    }

    private void fetchAuthorizedFeed() {
        String endpoint = feedUrl.getText().toString().trim();
        if (!endpoint.startsWith("https://")) {
            setStatus("Introduce una dirección HTTPS válida de una fuente autorizada.");
            return;
        }
        setStatus("Consultando fuente externa…");
        networkExecutor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(endpoint);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty("Accept", "application/json");
                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                if (stream == null) throw new Exception("Respuesta HTTP " + code);
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
                StringBuilder body = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
                reader.close();
                if (code < 200 || code >= 300) throw new Exception("Respuesta HTTP " + code);
                JSONObject json = new JSONObject(body.toString());
                JSONArray array = json.optJSONArray("events");
                if (array == null) throw new Exception("El JSON no contiene el arreglo 'events'.");
                int imported = 0;
                for (int i = 0; i < array.length(); i++) {
                    JSONObject item = array.optJSONObject(i);
                    if (item == null) continue;
                    String name = item.optString("name", "Evento externo");
                    String timestamp = item.optString("timestamp", now());
                    String source = item.optString("source", "HTTPS autorizado");
                    String description = item.optString("description", name + " · " + timestamp + " · " + source);
                    addEvent("HTTPS", description);
                    imported++;
                }
                final int count = imported;
                runOnUiThread(() -> setStatus("Consulta completada. Eventos importados: " + count));
            } catch (Exception e) {
                runOnUiThread(() -> setStatus("No se pudo consultar la fuente: " + e.getMessage()));
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (scanning && scanner != null) {
            try { scanner.stopScan(scanCallback); } catch (SecurityException ignored) {}
        }
        networkExecutor.shutdownNow();
    }
}
