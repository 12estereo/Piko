package com.matrixcodezero.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(5, 8, 5);
    private final int panel = Color.rgb(13, 23, 13);
    private final int green = Color.rgb(57, 255, 20);
    private final int white = Color.rgb(225, 238, 225);
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(28));
        root.setBackgroundColor(bg);
        scroll.addView(root);

        TextView logo = text("MATRIX CODE ZERO", 27, green, true);
        logo.setGravity(Gravity.CENTER);
        root.addView(logo);
        TextView sub = text("MOBILE PRIVACY  •  SECURITY CONTROL CENTER", 11, white, true);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);
        addGap(18);
        TextView notice = text("CENTRO DE CONTROL LOCAL\\nEsta aplicación no te espía ni envía datos. No solicita permisos de cámara, micrófono, ubicación, SIM, Bluetooth ni Internet.", 14, white, false);
        notice.setPadding(dp(14), dp(14), dp(14), dp(14));
        notice.setBackgroundColor(panel);
        root.addView(notice);

        section("01  SENSOR PRIVACY");
        addButton("Abrir controles de privacidad de Android", () -> open(Settings.ACTION_PRIVACY_SETTINGS));
        addButton("Abrir permisos de aplicaciones", () -> open(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:" + getPackageName()));
        addButton("Abrir información de esta aplicación", () -> open(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:" + getPackageName()));
        addNote("Usa los interruptores de acceso a cámara y micrófono de Android cuando quieras bloquear esos sensores a nivel del sistema. Si los desactivas, las llamadas no podrán usar el sensor correspondiente.");

        section("02  CELLULAR PRIVACY  •  SIM ÚNICA");
        addButton("Abrir ajustes de red móvil / SIM", () -> openFirst(
            Settings.ACTION_NETWORK_OPERATOR_SETTINGS,
            Settings.ACTION_DATA_ROAMING_SETTINGS,
            Settings.ACTION_WIRELESS_SETTINGS));
        addButton("Abrir ajustes de modo avión", () -> open(Settings.ACTION_AIRPLANE_MODE_SETTINGS));
        addButton("Abrir ajustes de seguridad", () -> open(Settings.ACTION_SECURITY_SETTINGS));
        addNote("La operadora puede estimar la ubicación del teléfono mientras la SIM está registrada en la red celular. Una APK normal no puede impedir la triangulación ni detectar todos los IMSI Catchers. El modo avión corta la conexión celular cuando está activado; comprueba que la radio móvil quede apagada. Restringir 2G depende del modelo, Android y operador.");

        section("03  WEBRTC & BROWSER PRIVACY");
        addButton("Guía oficial de WebRTC en Brave", () -> web("https://support.brave.com/hc/en-us"));
        addButton("Probar fugas WebRTC", () -> web("https://browserleaks.com/webrtc"));
        addButton("Prueba WebRTC", () -> web("https://test.webrtc.org/"));
        addNote("En Brave busca: Configuración → Brave Shields y privacidad → Política de manejo de IP de WebRTC → Desactivar UDP no proxy. Esto solo afecta Brave, no todos los navegadores ni WhatsApp. Repite las pruebas en cada navegador.");

        section("04  WI-FI & NETWORK");
        addButton("Abrir ajustes de Wi-Fi", () -> open(Settings.ACTION_WIFI_SETTINGS));
        addButton("Abrir ajustes de conexiones", () -> open(Settings.ACTION_WIRELESS_SETTINGS));
        addNote("En la configuración de cada red Wi-Fi, utiliza MAC aleatoria si está disponible. La MAC Wi-Fi no cambia la identidad de la SIM ni oculta la ubicación celular.");

        section("05  CALLS & MESSAGING");
        addButton("Abrir ajustes de WhatsApp", () -> open(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:com.whatsapp"));
        addNote("WhatsApp y Signal ofrecen cifrado de extremo a extremo para el contenido de comunicaciones compatibles. El cifrado no impide que un dispositivo comprometido acceda a lo que ve o escucha localmente. Revisa los permisos de micrófono y cámara.");

        section("06  SECURITY CHECKLIST");
        addNote("• Mantén Android y las aplicaciones actualizados.\\n• Instala aplicaciones solo de fuentes confiables.\\n• Revisa periódicamente el Panel de privacidad.\\n• Activa PIN de la SIM y bloqueo de pantalla.\\n• No compartas códigos de verificación.\\n• No interpretes una prueba WebRTC o una señal celular aislada como prueba de espionaje.");

        TextView footer = text("MATRIX CODE ZERO  |  V1.0\\nPrivacidad práctica, sin falsas promesas.", 12, green, true);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(22), 0, dp(8));
        root.addView(footer);
        setContentView(scroll);
    }

    private void section(String s) {
        addGap(18);
        TextView t = text(s, 16, green, true);
        t.setPadding(0, dp(4), 0, dp(8));
        root.addView(t);
    }
    private void addButton(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(green);
        b.setTextSize(14);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(4), 0, dp(4));
        root.addView(b, p);
        b.setOnClickListener(v -> action.run());
    }
    private void addNote(String s) {
        TextView t = text(s, 13, white, false);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        t.setBackgroundColor(panel);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(4), 0, dp(8));
        root.addView(t, p);
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void addGap(int d) { View v = new View(this); root.addView(v, new LinearLayout.LayoutParams(1, dp(d))); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private void open(String action) { open(action, null); }
    private void open(String action, String data) {
        try {
            Intent i = new Intent(action);
            if (data != null) i.setData(Uri.parse(data));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Este ajuste no está disponible en esta versión de Android.", Toast.LENGTH_LONG).show();
        }
    }
    private void openFirst(String... actions) {
        for (String a : actions) {
            try { startActivity(new Intent(a)); return; } catch (Exception ignored) {}
        }
        Toast.makeText(this, "Abre Ajustes y busca Red móvil o SIM.", Toast.LENGTH_LONG).show();
    }
    private void web(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "No se pudo abrir el navegador.", Toast.LENGTH_SHORT).show(); }
    }
}
