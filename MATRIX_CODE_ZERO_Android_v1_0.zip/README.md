# MATRIX CODE ZERO — Android v1.0

Aplicación de orientación y accesos directos para privacidad móvil.

## Qué incluye
- Accesos a los controles de privacidad, permisos y seguridad de Android.
- Accesos a red móvil/SIM, modo avión y Wi-Fi.
- Guía de WebRTC para Brave y enlaces a pruebas.
- Consejos para WhatsApp, PIN de SIM y seguridad básica.

## Límites importantes
Esta aplicación no bloquea directamente las antenas celulares, no evita la triangulación de la operadora, no detecta de forma fiable todos los IMSI Catchers, no cambia la MAC del sistema, no controla WebRTC globalmente y no intercepta ni modifica llamadas. Android no permite que una APK ordinaria haga esas funciones sin capacidades especiales del sistema. Los botones abren ajustes oficiales del teléfono.

## Privacidad
No declara permisos sensibles ni permiso de Internet. No recopila ni transmite datos.
